# PROJET LARAVEL
Ajustement par rapport à la version vidéo (les instructions écrites devraient être à jour)

## LARAVEL 1

### Étape 1
- Vous pouvez prendre VS Code
- Vous pouvez utiliser le terminal de VS Code
- Pour installer une version antérieure, utiliser la commande 

    ```composer create-project --prefer-dist laravel/laravel . "5.6.*"```
- Si lors de l'installation, on vous demande un token, lisez et suivez les instructions.

### Étape 2
#### ATTENTION
Après avoir __cloné__ un dépôt *Laravel*, vous devez faire `composer update` pour réinstaller le gros de l'application.

Ensuite, vous devez vous assurer d'avoir un fichier `.env` (même vide) et puis faire la commande `php artisan key:generate`. N'oubliez pas de choisir la bonne branche ou le bon tag.


## LARAVEL 2
à venir

## LARAVEL 2.5
à venir

## LARAVEL 3
à venir
