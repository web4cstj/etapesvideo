<div id="templatemo_footer">

<a href="#templatemo_header" class="goto_top"></a>
<div class="col_4">
    <h5>Pages</h5>
    <ul class="footer_list">
        <li><a href="index.html">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="portfolio.html">Portfolio</a></li>
        <li><a href="blog.html">Blog</a></li>
        <li><a href="contact.html">Contact</a></li>
    </ul>
</div>

<div class="col_4">
    <h5>Partners</h5>
    <ul class="footer_list">
        <li><a href="#">HTML CSS Templates</a></li>
        <li><a href="#">Web Design Tips</a></li>
        <li><a href="#">Free Flash Gallery</a></li>
        <li><a href="#">Website Templates</a></li>
        <li><a href="#">Free Graphics</a></li>
    </ul>
</div>

<div class="col_4">
    <h5>Twitter</h5>
    <ul class="twitter_post">
        <li>Suspendisse at scelerisque urna. Aenean tincidunt massa in tellus varius ultricies. <a href="#">http://bit.ly/13IwZO</a></li>
        <li>Proin dignissim, diam nec <a href="#">@TemplateMo</a> enim lorem tempus orci, ac imperdiet purus in justo.</li>
    </ul>
</div>

<div class="col_4 no_margin_right">
    <h5>Follow Us</h5>
    <div class="footer_social_button">
        <a href="#"><img src="images/facebook.png" title="facebook" alt="facebook" /></a>
        <a href="#"><img src="images/flickr.png" title="flickr" alt="flickr" /></a>
        <a href="#"><img src="images/twitter.png" title="twitter" alt="twitter" /></a>
        <a href="#"><img src="images/youtube.png" title="youtube" alt="youtube" /></a>
        <a href="#"><img src="images/feed.png" title="rss" alt="rss" /></a>
    </div>

    <div class="cleaner h20"></div>

    <p>Copyright © 2048 <br /> Your Company Name</p>

</div>

<div class="cleaner"></div>
</div> <!-- end of footer -->

