<div class="post">
    <h2><?php echo e($titre); ?></h2>
    <?php echo e($contenu); ?>

    <a href="blog_post.html" class="more float_r">More</a>
    <?php echo e($slot); ?>

    <div class="cleaner"></div>
</div>
