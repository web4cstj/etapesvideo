<?php $__env->startSection('contenu'); ?>
<?php echo $__env->make('users.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('interface.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>