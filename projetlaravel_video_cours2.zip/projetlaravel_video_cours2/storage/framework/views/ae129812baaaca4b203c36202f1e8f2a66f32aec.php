<?php $__env->startSection('contenu'); ?>
    <?php $__env->startComponent('interface.post'); ?>
        <?php $__env->slot('titre'); ?>
            <?php echo e($user->prenom); ?> <em><?php echo e($user->nom); ?></em>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('contenu'); ?>
            <div><?php echo e($user->email); ?></div>
            <div><?php echo e($user->tel); ?></div>
            <address>
                <div><?php echo e($user->adresse); ?></div>
                <div><?php echo e($user->ville); ?> <?php echo e($user->province); ?></div>
                <div><?php echo e($user->codepostal); ?></div>
            </address>
            <p><?php echo e($user->citation); ?></p>
        <?php $__env->endSlot(); ?>
        <div class="posts">
            <h3>Ses articles</h3>
            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li>
                    <a href="<?php echo e(action('PostController@show', $post)); ?>"><?php echo e($post->titre); ?></a>
                </li>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('interface.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>