<?php $__env->startSection('contenu'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('techno.post'); ?>
            <?php $__env->slot('titre'); ?>
                <?php echo e($user->prenom); ?> <em><?php echo e($user->nom); ?></em>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('contenu'); ?>
                <div><?php echo e($user->email); ?></div>
                <div><?php echo e($user->tel); ?></div>
                <address>
                    <div><?php echo e($user->adresse); ?></div>
                    <div><?php echo e($user->ville); ?> <?php echo e($user->province); ?></div>
                    <div><?php echo e($user->codepostal); ?></div>
                </address>
                <p><?php echo e($user->citation); ?></p>
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('techno.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>