<?php $__env->startSection('contenu'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('interface.post'); ?>
            <?php $__env->slot('titre'); ?>
                <a href="<?php echo e(action('UserController@show', $user)); ?>"><?php echo e($user->prenom); ?> <em><?php echo e($user->nom); ?></em></a>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('contenu'); ?>
                <div><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></div>
                <p><?php echo e($user->nbPosts); ?> articles</p>
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('interface.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>