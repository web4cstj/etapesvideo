<?php echo e(Form::model($user)); ?>

<table border="1">
	<tbody>
		<tr>
			<th><?php echo e(Form::label('nom', 'Nom')); ?></th>
			<td><?php echo e(Form::text('nom')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('prenom', 'Prénom')); ?></th>
			<td><?php echo e(Form::text('prenom')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('name', 'Nom d\'usager')); ?></th>
			<td><?php echo e(Form::text('name')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('password', 'Mot de passe')); ?></th>
			<td><?php echo e(Form::password('password')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('email', 'Courriel')); ?></th>
			<td><?php echo e(Form::email('email')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('tel', 'Téléphone')); ?></th>
			<td><?php echo e(Form::text('tel')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('adresse', 'Adresse')); ?></th>
			<td><?php echo e(Form::text('adresse')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('ville', 'Ville')); ?></th>
			<td><?php echo e(Form::text('ville')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('province', 'Province')); ?></th>
			<td><?php echo e(Form::text('province')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('codepostal', 'Code postal')); ?></th>
			<td><?php echo e(Form::text('codepostal')); ?></td>
		</tr>
		<tr>
			<th><?php echo e(Form::label('citation', 'Citation')); ?></th>
			<td><?php echo e(Form::textarea('citation')); ?></td>
		</tr>
		<tr>
			<th colspan="2"><?php echo e(Form::submit()); ?> <input type="submit" name="annuler" value="Annuler"></th>
		</tr>
	</tbody>
</table>
<?php echo e(Form::close()); ?>