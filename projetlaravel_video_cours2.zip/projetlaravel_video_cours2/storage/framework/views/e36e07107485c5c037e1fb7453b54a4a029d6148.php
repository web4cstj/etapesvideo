<?php $__env->startSection('contenu'); ?>
    <?php $__env->startComponent('interface.post'); ?>
        <?php $__env->slot('titre'); ?>
            <img src="<?php echo e(asset('images/blog/02.jpg')); ?>" alt="Image 02" class="image_frame image_fl" />
            <?php echo e($post->titre); ?>

            <div class="meta">
            by <strong><a href="<?php echo e(action('UserController@show', $post->user)); ?>"><?php echo e($post->user->nomComplet); ?></a></strong> 
            on <strong><?php echo e($post->updated_at); ?></strong> 
            in <strong><a href="#">Coding</a>, <a href="#">HTML</a></strong> 
            | <strong><a href="#">196 comments</a></strong>
            </div>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('contenu'); ?>
            <p><?php echo e($post->contenu); ?></p>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('interface.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>