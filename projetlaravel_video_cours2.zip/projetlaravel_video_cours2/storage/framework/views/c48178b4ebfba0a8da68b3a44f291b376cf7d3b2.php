<?php $__env->startSection('contenu'); ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <ul>
       <li>
            <a href="<?php echo e(action('PostController@show', $post)); ?>"><?php echo e($post->titre); ?></a>
           par <a href="<?php echo e(action('UserController@show', $post->user)); ?>"><?php echo e($post->user->nomComplet); ?></a>
       </li>
   </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('interface.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>