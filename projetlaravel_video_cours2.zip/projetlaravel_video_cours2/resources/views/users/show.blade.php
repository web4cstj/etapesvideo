@extends('interface.index')
@section('contenu')
    @component('interface.post')
        @slot('titre')
            {{$user->prenom}} <em>{{$user->nom}}</em>
        @endslot
        @slot('contenu')
            <div>{{$user->email}}</div>
            <div>{{$user->tel}}</div>
            <address>
                <div>{{$user->adresse}}</div>
                <div>{{$user->ville}} {{$user->province}}</div>
                <div>{{$user->codepostal}}</div>
            </address>
            <p>{{$user->citation}}</p>
        @endslot
    @endcomponent
@endsection
