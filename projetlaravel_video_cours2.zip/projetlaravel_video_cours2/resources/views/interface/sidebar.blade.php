<div id="sidebar">
    <h3>Services</h3>
    <ul class="templatemo_list">
        <li>Augue felis pharetra felis</li>
        <li>Condimentum et vulputate</li>
        <li>Dolor vel condimentum</li>
        <li>Felis pharetra felis sed</li>
        <li>Integer placerat dolor vel</li>
        <li>Tortor mi in massa donec</li>
        <li>Vulputate tortor mi in massa</li>
    </ul>
    <div class="cleaner h40"></div>
    <h3>Testimonials</h3>
    <p class="testimonial">Nunc iaculis porta quam. Ut molestie hendrerit commodo.</p>
    <cite>Johny <a href="#"><span>- Senior Webmaster</span></a></cite>
    <div class="cleaner h30"></div>
    <p class="testimonial">Aenean orci odio, iaculis sed luctus non, luctus elit nec quam.</p>
    <cite>Smith <a href="#"><span>- Database Designer</span></a></cite>
</div>
