	<div id="templatemo_header_sp">
    	<div id="site_title"><h1><a href="#">Techno Template</a></h1></div>
    </div> <!-- end of header -->
